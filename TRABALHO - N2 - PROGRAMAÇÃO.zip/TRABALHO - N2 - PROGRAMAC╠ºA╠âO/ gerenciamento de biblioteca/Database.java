import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {
    public static void init() {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:biblioteca.db");
             Statement stmt = conn.createStatement()) {
            String sqlLivros = "CREATE TABLE IF NOT EXISTS livros (" +
                               "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                               "titulo TEXT NOT NULL," +
                               "autor TEXT NOT NULL)";
            stmt.execute(sqlLivros);

            String sqlUsuarios = "CREATE TABLE IF NOT EXISTS usuarios (" +
                                 "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                                 "nome TEXT NOT NULL," +
                                 "email TEXT NOT NULL)";
            stmt.execute(sqlUsuarios);

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
