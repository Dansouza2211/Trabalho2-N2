public class Livro {
    private int livroId;
    private String titulo;
    private String autor;

    public Livro(int livroId, String titulo, String autor) {
        this.livroId = livroId;
        this.titulo = titulo;
        this.autor = autor;
    }

    public int getLivroId() {
        return livroId;
    }

    public void setLivroId(int livroId) {
        this.livroId = livroId;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }
}
