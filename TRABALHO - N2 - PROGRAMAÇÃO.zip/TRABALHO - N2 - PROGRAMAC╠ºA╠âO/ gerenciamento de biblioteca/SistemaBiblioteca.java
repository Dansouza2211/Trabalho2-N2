import java.util.Scanner;

public class SistemaBiblioteca {
    private Biblioteca biblioteca;

    public SistemaBiblioteca() {
        this.biblioteca = new Biblioteca();
        Database.init();
    }

    public void iniciar() {
        Scanner scanner = new Scanner(System.in);
        int opcao;

        do {
            mostrarMenu();
            opcao = scanner.nextInt();
            scanner.nextLine(); // Consumir nova linha

            switch (opcao) {
                case 1:
                    cadastrarLivro(scanner);
                    break;
                case 2:
                    consultarLivro(scanner);
                    break;
                case 3:
                    atualizarLivro(scanner);
                    break;
                case 4:
                    excluirLivro(scanner);
                    break;
                case 5:
                    cadastrarUsuario(scanner);
                    break;
                case 6:
                    consultarUsuario(scanner);
                    break;
                case 7:
                    atualizarUsuario(scanner);
                    break;
                case 8:
                    excluirUsuario(scanner);
                    break;
                case 9:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida.");
            }
        } while (opcao != 9);

        scanner.close();
    }

    private void mostrarMenu() {
        System.out.println("\n--- Sistema de Biblioteca ---");
        System.out.println("1. Cadastrar Livro");
        System.out.println("2. Consultar Livro");
        System.out.println("3. Atualizar Livro");
        System.out.println("4. Excluir Livro");
        System.out.println("5. Cadastrar Usuário");
        System.out.println("6. Consultar Usuário");
        System.out.println("7. Atualizar Usuário");
        System.out.println("8. Excluir Usuário");
        System.out.println("9. Sair");
        System.out.print("Escolha uma opção: ");
    }

    private void cadastrarLivro(Scanner scanner) {
        System.out.print("Digite o título do livro: ");
        String titulo = scanner.nextLine();
        System.out.print("Digite o autor do livro: ");
        String autor = scanner.nextLine();

        Livro livro = new Livro(0, titulo, autor);
        biblioteca.adicionarLivro(livro);
        System.out.println("Livro cadastrado com sucesso!");
    }

    private void consultarLivro(Scanner scanner) {
        System.out.print("Digite o ID do livro: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consumir nova linha

        Livro livro = biblioteca.consultarLivro(id);
        if (livro != null) {
            System.out.println("ID: " + livro.getLivroId());
            System.out.println("Título: " + livro.getTitulo());
            System.out.println("Autor: " + livro.getAutor());
        } else {
            System.out.println("Livro não encontrado.");
        }
    }

    private void atualizarLivro(Scanner scanner) {
        System.out.print("Digite o ID do livro: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consumir nova linha

        System.out.print("Digite o novo título do livro: ");
        String titulo = scanner.nextLine();
        System.out.print("Digite o novo autor do livro: ");
        String autor = scanner.nextLine();

        Livro livro = new Livro(id, titulo, autor);
        biblioteca.atualizarLivro(livro);
        System.out.println("Livro atualizado com sucesso!");
    }

    private void excluirLivro(Scanner scanner) {
        System.out.print("Digite o ID do livro: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consumir nova linha

        biblioteca.excluirLivro(id);
        System.out.println("Livro excluído com sucesso!");
    }

    private void cadastrarUsuario(Scanner scanner) {
        System.out.print("Digite o nome do usuário: ");
        String nome = scanner.nextLine();
        System.out.print("Digite o email do usuário: ");
        String email = scanner.nextLine();

        Usuario usuario = new Usuario(0, nome, email);
        biblioteca.adicionarUsuario(usuario);
        System.out.println("Usuário cadastrado com sucesso!");
    }

    private void consultarUsuario(Scanner scanner) {
        System.out.print("Digite o ID do usuário: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consumir nova linha

        Usuario usuario = biblioteca.consultarUsuario(id);
        if (usuario != null) {
            System.out.println("ID: " + usuario.getUsuarioId());
            System.out.println("Nome: " + usuario.getNome());
            System.out.println("Email: " + usuario.getEmail());
        } else {
            System.out.println("Usuário não encontrado.");
        }
    }

    private void atualizarUsuario(Scanner scanner) {
        System.out.print("Digite o ID do usuário: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consumir nova linha

        System.out.print("Digite o novo nome do usuário: ");
        String nome = scanner.nextLine();
        System.out.print("Digite o novo email do usuário: ");
        String email = scanner.nextLine();

        Usuario usuario = new Usuario(id, nome, email);
        biblioteca.atualizarUsuario(usuario);
        System.out.println("Usuário atualizado com sucesso!");
    }

    private void excluirUsuario(Scanner scanner) {
        System.out.print("Digite o ID do usuário: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consumir nova linha

        biblioteca.excluirUsuario(id);
        System.out.println("Usuário excluído com sucesso!");
    }

    public static void main(String[] args) {
        SistemaBiblioteca sistema = new SistemaBiblioteca();
        sistema.iniciar();
    }
}
