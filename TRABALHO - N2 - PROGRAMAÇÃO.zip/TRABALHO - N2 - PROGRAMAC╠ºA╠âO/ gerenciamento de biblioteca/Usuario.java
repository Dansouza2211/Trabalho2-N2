public class Usuario extends Pessoa {
    private int usuarioId;

    public Usuario(int usuarioId, String nome, String email) {
        super(nome, email);
        this.usuarioId = usuarioId;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }
}
